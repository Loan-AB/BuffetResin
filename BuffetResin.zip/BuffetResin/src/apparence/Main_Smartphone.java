package apparence;

public class Main_Smartphone 
{

	/**
	 * @param args
	 * @author loanb
	 */
	public static void main(String[] args) 
	{
		MaFenetre mf = new MaFenetre();
	}
}
