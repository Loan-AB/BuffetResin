package gestionCalculatrice;

public class SigEffacer extends Sigle {

	/**
	 * permet de definir le comportement du sigle effacer
	 * @param signe
	 * @author loanb
	 */
	public SigEffacer(String signe) {
		super(signe);
	}

	/**
	 * @param chiffreStocker
	 * @param chiffreAfficher
	 * @return
	 */
	public static double effacer(double chiffreStocker, double chiffreAfficher) {

		return 0;
	}
}
