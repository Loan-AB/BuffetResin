package gestionCalculatrice;

/**
 * @author loanb
 * 
 * permet de definir la strtegie des operations
 *
 */
public abstract class Operation extends Symbole implements OperationStrategy {

}
