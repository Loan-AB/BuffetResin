package gestionCalculatrice;

public class OperEgal extends Operation{

	/* (non-Javadoc)
	 * @see gestionCalculatrice.OperationStrategy#doOper(double, double)
	 * doOper
	 * permet le reste lors du clalcul
	 * @author loanb
	 */
	@Override
	public double doOper(double nb1, double nb2) {
		return 0;
	}

}
