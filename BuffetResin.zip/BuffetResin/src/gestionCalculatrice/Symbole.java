package gestionCalculatrice;

/**
 * cr�e une class pour les symboles
 * @author loanb
 *
 */
public abstract class Symbole {

}
